<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Doctor\DoctorController;
use App\Http\Controllers\Pharmacy\PharmacyController;
use App\Http\Controllers\Reception\ReceptionController;
use App\Http\Livewire\PatientRegistration;
use App\Http\Livewire\PatientDashboard;
use App\Http\Livewire\TreatmentManagement;
use App\Http\Livewire\MedicineInventory;
use App\Http\Livewire\DispensingScreen;
use App\Http\Livewire\InvoiceGeneration;
use App\Http\Livewire\DoctorProfile;
use App\Http\Livewire\ReportGenerator;

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('login', [AuthController::class, 'login']);
    Route::get('register', [AuthController::class, 'showRegistrationForm'])->name('register');
    Route::post('register', [AuthController::class, 'register']);
    Route::post('logout', [AuthController::class, 'logout'])->name('logout');
});

// Protected Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return redirect()->route(auth()->user()->role . '.dashboard');
    })->name('dashboard');

    // Admin Routes
    Route::middleware(['role:admin'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/users', [AdminController::class, 'users'])->name('users');
        Route::get('/reports', [AdminController::class, 'reports'])->name('reports');
        Route::get('/settings', [AdminController::class, 'settings'])->name('settings');
    });

    // Doctor Routes
    Route::middleware(['role:doctor'])->prefix('doctor')->name('doctor.')->group(function () {
        Route::get('/dashboard', [DoctorController::class, 'dashboard'])->name('dashboard');
        Route::get('/profile', DoctorProfile::class)->name('profile');
        Route::get('/patients', [DoctorController::class, 'patients'])->name('patients');
        Route::get('/treatments', TreatmentManagement::class)->name('treatments');
        Route::get('/appointments', [DoctorController::class, 'appointments'])->name('appointments');
    });

    // Pharmacy Routes
    Route::middleware(['role:pharmacy'])->prefix('pharmacy')->name('pharmacy.')->group(function () {
        Route::get('/dashboard', [PharmacyController::class, 'dashboard'])->name('dashboard');
        Route::get('/inventory', MedicineInventory::class)->name('inventory');
        Route::get('/dispensing', DispensingScreen::class)->name('dispensing');
        Route::get('/reports', [PharmacyController::class, 'reports'])->name('reports');
    });

    // Reception Routes
    Route::middleware(['role:reception'])->prefix('reception')->name('reception.')->group(function () {
        Route::get('/dashboard', [ReceptionController::class, 'dashboard'])->name('dashboard');
        Route::get('/patient-registration', PatientRegistration::class)->name('patient-registration');
        Route::get('/patients', [ReceptionController::class, 'patients'])->name('patients');
        Route::get('/appointments', [ReceptionController::class, 'appointments'])->name('appointments');
        Route::get('/billing', InvoiceGeneration::class)->name('billing');
    });

    // Shared Routes
    Route::get('/patient-dashboard/{patient}', PatientDashboard::class)->name('patient.dashboard');
    Route::get('/reports', ReportGenerator::class)->name('reports');
});

// API Routes for AJAX calls
Route::middleware(['auth'])->prefix('api')->name('api.')->group(function () {
    Route::get('/patients/search', [ReceptionController::class, 'searchPatients'])->name('patients.search');
    Route::get('/medicines/search', [PharmacyController::class, 'searchMedicines'])->name('medicines.search');
    Route::get('/doctors/search', [ReceptionController::class, 'searchDoctors'])->name('doctors.search');
    Route::post('/appointments/check-availability', [ReceptionController::class, 'checkAvailability'])->name('appointments.check-availability');
});