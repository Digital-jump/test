<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Patient;
use App\Models\Treatment;
use App\Models\Transaction;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'total_patients' => Patient::count(),
            'active_treatments' => Treatment::where('status', 'Active')->count(),
            'total_revenue' => Transaction::where('status', 'Paid')->sum('total'),
            'total_users' => User::count(),
        ];

        $recentPatients = Patient::latest()->take(5)->get();
        $recentTransactions = Transaction::latest()->take(5)->get();

        return view('admin.dashboard', compact('stats', 'recentPatients', 'recentTransactions'));
    }

    public function users()
    {
        $users = User::with('roles')->latest()->paginate(10);
        return view('admin.users', compact('users'));
    }

    public function reports()
    {
        return view('admin.reports');
    }

    public function settings()
    {
        return view('admin.settings');
    }
}