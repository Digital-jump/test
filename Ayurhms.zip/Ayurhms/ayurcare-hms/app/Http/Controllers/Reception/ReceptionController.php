<?php

namespace App\Http\Controllers\Reception;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\User;
use Illuminate\Http\Request;

class ReceptionController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'today_appointments' => Appointment::whereDate('appointment_date', today())->count(),
            'total_patients' => Patient::count(),
            'pending_appointments' => Appointment::where('status', 'Scheduled')->count(),
            'new_patients_this_month' => Patient::whereMonth('created_at', now()->month)->count(),
        ];

        $todayAppointments = Appointment::with(['patient', 'doctor'])
            ->whereDate('appointment_date', today())
            ->orderBy('appointment_date')
            ->get();

        $recentPatients = Patient::latest()->take(5)->get();

        return view('reception.dashboard', compact('stats', 'todayAppointments', 'recentPatients'));
    }

    public function patients()
    {
        $patients = Patient::latest()->paginate(10);
        return view('reception.patients', compact('patients'));
    }

    public function appointments()
    {
        $appointments = Appointment::with(['patient', 'doctor'])
            ->latest()
            ->paginate(10);

        return view('reception.appointments', compact('appointments'));
    }

    public function searchPatients(Request $request)
    {
        $query = $request->get('q');
        $patients = Patient::where('full_name', 'like', "%{$query}%")
            ->orWhere('uhid', 'like', "%{$query}%")
            ->orWhere('phone', 'like', "%{$query}%")
            ->take(10)
            ->get();

        return response()->json($patients);
    }

    public function searchDoctors(Request $request)
    {
        $query = $request->get('q');
        $doctors = User::where('role', 'doctor')
            ->where('is_active', true)
            ->where(function($q) use ($query) {
                $q->where('name', 'like', "%{$query}%")
                  ->orWhere('email', 'like', "%{$query}%");
            })
            ->take(10)
            ->get();

        return response()->json($doctors);
    }

    public function checkAvailability(Request $request)
    {
        $doctorId = $request->get('doctor_id');
        $date = $request->get('date');
        
        $appointments = Appointment::where('doctor_id', $doctorId)
            ->whereDate('appointment_date', $date)
            ->where('status', '!=', 'Cancelled')
            ->get();

        return response()->json($appointments);
    }
}