<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\Treatment;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function dashboard()
    {
        $doctorId = auth()->id();
        
        $stats = [
            'today_appointments' => Appointment::where('doctor_id', $doctorId)
                ->whereDate('appointment_date', today())
                ->count(),
            'active_treatments' => Treatment::where('doctor_id', $doctorId)
                ->where('status', 'Active')
                ->count(),
            'completed_treatments' => Treatment::where('doctor_id', $doctorId)
                ->where('status', 'Completed')
                ->count(),
            'total_patients' => Patient::whereHas('treatments', function($query) use ($doctorId) {
                $query->where('doctor_id', $doctorId);
            })->count(),
        ];

        $todayAppointments = Appointment::where('doctor_id', $doctorId)
            ->whereDate('appointment_date', today())
            ->orderBy('appointment_date')
            ->get();

        $upcomingAppointments = Appointment::where('doctor_id', $doctorId)
            ->where('appointment_date', '>', now())
            ->where('status', 'Scheduled')
            ->orderBy('appointment_date')
            ->take(5)
            ->get();

        return view('doctor.dashboard', compact('stats', 'todayAppointments', 'upcomingAppointments'));
    }

    public function patients()
    {
        $doctorId = auth()->id();
        $patients = Patient::whereHas('treatments', function($query) use ($doctorId) {
            $query->where('doctor_id', $doctorId);
        })->latest()->paginate(10);

        return view('doctor.patients', compact('patients'));
    }

    public function appointments()
    {
        $doctorId = auth()->id();
        $appointments = Appointment::where('doctor_id', $doctorId)
            ->latest()
            ->paginate(10);

        return view('doctor.appointments', compact('appointments'));
    }
}