<?php

namespace App\Http\Controllers\Pharmacy;

use App\Http\Controllers\Controller;
use App\Models\Medicine;
use App\Models\Transaction;
use Illuminate\Http\Request;

class PharmacyController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'total_medicines' => Medicine::count(),
            'low_stock' => Medicine::where('stock_quantity', '<=', \DB::raw('reorder_level'))->count(),
            'expiring_soon' => Medicine::where('exp_date', '<=', now()->addMonths(3))->count(),
            'today_transactions' => Transaction::whereDate('created_at', today())->count(),
        ];

        $lowStockMedicines = Medicine::where('stock_quantity', '<=', \DB::raw('reorder_level'))
            ->latest()
            ->take(5)
            ->get();

        $expiringMedicines = Medicine::where('exp_date', '<=', now()->addMonths(3))
            ->latest()
            ->take(5)
            ->get();

        return view('pharmacy.dashboard', compact('stats', 'lowStockMedicines', 'expiringMedicines'));
    }

    public function reports()
    {
        return view('pharmacy.reports');
    }

    public function searchMedicines(Request $request)
    {
        $query = $request->get('q');
        $medicines = Medicine::where('name', 'like', "%{$query}%")
            ->orWhere('code', 'like', "%{$query}%")
            ->where('is_active', true)
            ->where('stock_quantity', '>', 0)
            ->take(10)
            ->get();

        return response()->json($medicines);
    }
}