<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Patient;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class PatientRegistration extends Component
{
    use WithFileUploads;

    public $currentStep = 1;
    public $totalSteps = 3;

    // Step 1: Basic Information
    public $full_name;
    public $gender;
    public $date_of_birth;
    public $age;
    public $aadhaar_number;
    public $uhid;

    // Step 2: Contact Information
    public $mobile;
    public $email;
    public $emergency_contact;
    public $emergency_contact_name;
    public $address;

    // Step 3: Ayurvedic Information
    public $prakriti;
    public $dosha_types = [];
    public $allergies;
    public $registration_type = 'OPD';
    public $photo;

    protected $rules = [
        // Step 1
        'full_name' => 'required|string|min:3|max:255',
        'gender' => 'required|in:Male,Female,Other',
        'date_of_birth' => 'required|date|before:today',
        'aadhaar_number' => 'nullable|string|size:12|regex:/^[0-9]+$/',
        
        // Step 2
        'mobile' => 'required|string|regex:/^[0-9]{10}$/',
        'email' => 'nullable|email|max:255',
        'emergency_contact' => 'required|string|regex:/^[0-9]{10}$/',
        'emergency_contact_name' => 'required|string|min:3|max:255',
        'address' => 'required|string|min:10|max:1000',
        
        // Step 3
        'prakriti' => 'required|in:Vata,Pitta,Kapha,Sama',
        'dosha_types' => 'required|array|min:1',
        'allergies' => 'nullable|string|max:500',
        'registration_type' => 'required|in:OPD,IPD',
        'photo' => 'nullable|image|max:2048|mimes:jpeg,png,jpg',
    ];

    protected $messages = [
        'full_name.required' => 'Full name is required',
        'mobile.regex' => 'Mobile number must be 10 digits',
        'emergency_contact.regex' => 'Emergency contact must be 10 digits',
        'aadhaar_number.size' => 'Aadhaar number must be 12 digits',
        'aadhaar_number.regex' => 'Aadhaar number must contain only digits',
    ];

    public function mount()
    {
        $this->uhid = Patient::generateUhid();
        $this->dosha_types = [];
    }

    public function updatedDateOfBirth($value)
    {
        if ($value) {
            $this->age = Carbon::parse($value)->age;
        }
    }

    public function nextStep()
    {
        $this->validateStep();
        if ($this->currentStep < $this->totalSteps) {
            $this->currentStep++;
        }
    }

    public function previousStep()
    {
        if ($this->currentStep > 1) {
            $this->currentStep--;
        }
    }

    public function validateStep()
    {
        $rules = [];
        
        switch ($this->currentStep) {
            case 1:
                $rules = [
                    'full_name' => $this->rules['full_name'],
                    'gender' => $this->rules['gender'],
                    'date_of_birth' => $this->rules['date_of_birth'],
                    'aadhaar_number' => $this->rules['aadhaar_number'],
                ];
                break;
            case 2:
                $rules = [
                    'mobile' => $this->rules['mobile'],
                    'email' => $this->rules['email'],
                    'emergency_contact' => $this->rules['emergency_contact'],
                    'emergency_contact_name' => $this->rules['emergency_contact_name'],
                    'address' => $this->rules['address'],
                ];
                break;
            case 3:
                $rules = [
                    'prakriti' => $this->rules['prakriti'],
                    'dosha_types' => $this->rules['dosha_types'],
                    'allergies' => $this->rules['allergies'],
                    'registration_type' => $this->rules['registration_type'],
                    'photo' => $this->rules['photo'],
                ];
                break;
        }

        $this->validate($rules);
    }

    public function submit()
    {
        $this->validate();

        // Handle photo upload
        $photoPath = null;
        if ($this->photo) {
            $photoPath = $this->photo->store('patients/photos', 'public');
        }

        // Prepare contact info
        $contactInfo = [
            'mobile' => $this->mobile,
            'email' => $this->email,
            'emergency_contact' => [
                'name' => $this->emergency_contact_name,
                'phone' => $this->emergency_contact,
            ],
            'address' => $this->address,
        ];

        // Prepare ayurvedic info
        $ayurvedicInfo = [
            'prakriti' => $this->prakriti,
            'dosha_types' => $this->dosha_types,
            'allergies' => $this->allergies,
            'registration_type' => $this->registration_type,
        ];

        // Create patient
        $patient = Patient::create([
            'uhid' => $this->uhid,
            'full_name' => $this->full_name,
            'gender' => $this->gender,
            'date_of_birth' => $this->date_of_birth,
            'age' => $this->age,
            'aadhaar_number' => $this->aadhaar_number,
            'contact_info' => $contactInfo,
            'ayurvedic_info' => $ayurvedicInfo,
            'photo' => $photoPath,
            'is_active' => true,
        ]);

        // Reset form
        $this->reset();
        $this->uhid = Patient::generateUhid();
        $this->currentStep = 1;

        // Show success message
        session()->flash('message', 'Patient registered successfully! UHID: ' . $patient->uhid);
        
        // Redirect to patient dashboard
        return redirect()->route('patient.dashboard', $patient->id);
    }

    public function render()
    {
        return view('livewire.patient-registration');
    }
}