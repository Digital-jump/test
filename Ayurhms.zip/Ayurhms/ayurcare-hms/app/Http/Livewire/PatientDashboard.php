<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Patient;
use App\Models\Treatment;
use App\Models\Appointment;
use App\Models\Prescription;
use App\Models\TreatmentFeedback;

class PatientDashboard extends Component
{
    public $patient;
    public $ongoingTreatments;
    public $upcomingAppointments;
    public $activePrescriptions;
    public $pendingFeedback;
    public $stats;

    public function mount($patient)
    {
        $this->patient = Patient::findOrFail($patient);
        $this->loadDashboardData();
    }

    public function loadDashboardData()
    {
        $this->ongoingTreatments = $this->patient->getOngoingTreatments();
        $this->upcomingAppointments = $this->patient->getUpcomingAppointments();
        $this->activePrescriptions = $this->patient->getActivePrescriptions();
        $this->pendingFeedback = $this->patient->getPendingFeedback();

        $this->stats = [
            'total_treatments' => $this->patient->treatments()->count(),
            'completed_treatments' => $this->patient->treatments()->where('status', 'Completed')->count(),
            'total_appointments' => $this->patient->appointments()->count(),
            'total_spent' => $this->patient->transactions()->where('status', 'Paid')->sum('total'),
        ];
    }

    public function getTreatmentProgress($treatment)
    {
        return $treatment->getProgressPercentage();
    }

    public function getTreatmentDaysRemaining($treatment)
    {
        return $treatment->getDaysRemaining();
    }

    public function getMedicationDaysRemaining($prescription)
    {
        // Calculate remaining days based on prescription start date and duration
        $startDate = $prescription->created_at;
        $duration = $prescription->items->first()->duration ?? 0;
        $durationUnit = $prescription->items->first()->duration_unit ?? 'days';
        
        $endDate = match($durationUnit) {
            'days' => $startDate->addDays($duration),
            'weeks' => $startDate->addWeeks($duration),
            'months' => $startDate->addMonths($duration),
            default => $startDate->addDays($duration),
        };

        return max(0, now()->diffInDays($endDate, false));
    }

    public function submitFeedback($treatmentId, $rating, $feedback)
    {
        $treatment = Treatment::findOrFail($treatmentId);
        
        TreatmentFeedback::create([
            'treatment_id' => $treatmentId,
            'patient_id' => $this->patient->id,
            'doctor_id' => $treatment->doctor_id,
            'rating' => $rating,
            'feedback' => $feedback,
            'status' => 'Submitted',
        ]);

        $this->loadDashboardData();
        session()->flash('feedback_message', 'Thank you for your feedback!');
    }

    public function render()
    {
        return view('livewire.patient-dashboard');
    }
}