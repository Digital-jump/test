<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Transaction;
use App\Models\Patient;
use App\Models\Treatment;
use App\Models\Prescription;
use App\Models\PrescriptionItem;
use Livewire\WithPagination;

class InvoiceGeneration extends Component
{
    use WithPagination;

    public $search = '';
    public $filterStatus = '';
    public $showModal = false;
    public $selectedPatient = null;
    public $invoiceItems = [];
    public $subtotal = 0;
    public $discount = 0;
    public $tax = 0;
    public $total = 0;
    public $payment_method = 'Cash';
    public $notes = '';

    // Form fields for manual item
    public $manual_item_name = '';
    public $manual_item_price = 0;
    public $manual_item_quantity = 1;

    public function render()
    {
        $transactions = Transaction::with(['patient', 'creator'])
            ->when($this->search, function($query) {
                $query->where(function($q) {
                    $q->where('invoice_number', 'like', '%' . $this->search . '%')
                      ->orWhereHas('patient', function($q) {
                          $q->where('full_name', 'like', '%' . $this->search . '%')
                            ->orWhere('uhid', 'like', '%' . $this->search . '%');
                      });
                });
            })
            ->when($this->filterStatus, function($query) {
                $query->where('status', $this->filterStatus);
            })
            ->latest()
            ->paginate(10);

        return view('livewire.invoice-generation', [
            'transactions' => $transactions,
        ]);
    }

    public function createInvoice()
    {
        $this->resetForm();
        $this->showModal = true;
    }

    public function selectPatient($patientId)
    {
        $this->selectedPatient = Patient::findOrFail($patientId);
        $this->loadBillableItems();
    }

    public function loadBillableItems()
    {
        if (!$this->selectedPatient) return;

        $this->invoiceItems = [];

        // Load active treatments
        $treatments = $this->selectedPatient->treatments()
            ->where('status', 'Active')
            ->get();

        foreach ($treatments as $treatment) {
            $this->invoiceItems[] = [
                'type' => 'treatment',
                'id' => $treatment->id,
                'name' => $treatment->name . ' - ' . $treatment->type,
                'price' => $treatment->cost,
                'quantity' => 1,
                'selected' => false,
            ];
        }

        // Load active prescriptions that are not yet billed
        $prescriptions = $this->selectedPatient->prescriptions()
            ->where('status', 'Active')
            ->whereDoesntHave('transactions')
            ->get();

        foreach ($prescriptions as $prescription) {
            foreach ($prescription->items as $item) {
                if (!$item->dispensed) continue;
                
                $this->invoiceItems[] = [
                    'type' => 'medicine',
                    'id' => $item->id,
                    'name' => $item->medicine->name . ' - ' . $item->dosage,
                    'price' => $item->price,
                    'quantity' => $item->quantity,
                    'selected' => false,
                ];
            }
        }

        $this->calculateTotals();
    }

    public function toggleItem($index)
    {
        $this->invoiceItems[$index]['selected'] = !$this->invoiceItems[$index]['selected'];
        $this->calculateTotals();
    }

    public function addManualItem()
    {
        if (!$this->manual_item_name || $this->manual_item_price <= 0) {
            return;
        }

        $this->invoiceItems[] = [
            'type' => 'manual',
            'id' => null,
            'name' => $this->manual_item_name,
            'price' => $this->manual_item_price,
            'quantity' => $this->manual_item_quantity,
            'selected' => true,
        ];

        $this->manual_item_name = '';
        $this->manual_item_price = 0;
        $this->manual_item_quantity = 1;

        $this->calculateTotals();
    }

    public function removeItem($index)
    {
        unset($this->invoiceItems[$index]);
        $this->invoiceItems = array_values($this->invoiceItems);
        $this->calculateTotals();
    }

    public function calculateTotals()
    {
        $this->subtotal = 0;
        
        foreach ($this->invoiceItems as $item) {
            if ($item['selected']) {
                $this->subtotal += $item['price'] * $item['quantity'];
            }
        }

        $this->tax = $this->subtotal * 0.18; // 18% GST
        $this->total = $this->subtotal - $this->discount + $this->tax;
    }

    public function updatedDiscount()
    {
        $this->calculateTotals();
    }

    public function saveInvoice()
    {
        if (!$this->selectedPatient) {
            session()->flash('error', 'Please select a patient');
            return;
        }

        $selectedItems = array_filter($this->invoiceItems, function($item) {
            return $item['selected'];
        });

        if (empty($selectedItems)) {
            session()->flash('error', 'Please select at least one item');
            return;
        }

        $transaction = Transaction::create([
            'patient_id' => $this->selectedPatient->id,
            'invoice_number' => Transaction::generateInvoiceNumber(),
            'subtotal' => $this->subtotal,
            'discount' => $this->discount,
            'tax' => $this->tax,
            'total' => $this->total,
            'payment_method' => $this->payment_method,
            'status' => 'Pending',
            'items' => $selectedItems,
            'notes' => $this->notes,
            'created_by' => auth()->id(),
        ]);

        $this->resetForm();
        $this->showModal = false;
        
        session()->flash('message', 'Invoice created successfully! Invoice Number: ' . $transaction->invoice_number);
    }

    public function markAsPaid($transactionId)
    {
        $transaction = Transaction::findOrFail($transactionId);
        $transaction->markAsPaid();
        session()->flash('message', 'Invoice marked as paid!');
    }

    public function cancelInvoice($transactionId)
    {
        $transaction = Transaction::findOrFail($transactionId);
        $transaction->cancel();
        session()->flash('message', 'Invoice cancelled!');
    }

    public function printInvoice($transactionId)
    {
        $transaction = Transaction::with(['patient', 'creator'])
            ->findOrFail($transactionId);
        
        // This would generate a PDF or print view
        session()->flash('message', 'Print functionality would be implemented here');
    }

    public function resetForm()
    {
        $this->reset([
            'selectedPatient', 'invoiceItems', 'subtotal', 'discount', 
            'tax', 'total', 'payment_method', 'notes', 'manual_item_name', 
            'manual_item_price', 'manual_item_quantity'
        ]);
        $this->payment_method = 'Cash';
    }

    public function getStatusColor($status)
    {
        return match($status) {
            'Pending' => 'yellow',
            'Paid' => 'green',
            'Cancelled' => 'red',
            'Refunded' => 'orange',
            default => 'gray',
        };
    }
}