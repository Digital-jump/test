<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\User;
use App\Models\Appointment;
use App\Models\Treatment;
use App\Models\Transaction;
use Carbon\Carbon;
use Livewire\WithFileUploads;

class DoctorProfile extends Component
{
    use WithFileUploads;

    public $doctor;
    public $activeTab = 'profile';
    public $isEditing = false;
    public $profile_photo;

    // Editable fields
    public $name;
    public $email;
    public $phone;
    public $specializations = [];
    public $contact_info = [];

    // Schedule management
    public $weeklySchedule = [];
    public $appointmentDuration = 30;

    protected $rules = [
        'name' => 'required|string|min:3|max:255',
        'email' => 'required|email|max:255|unique:users,email,' . $this->doctor?->id,
        'phone' => 'required|string|max:20',
        'specializations' => 'required|array|min:1',
        'profile_photo' => 'nullable|image|max:2048|mimes:jpeg,png,jpg',
    ];

    public function mount()
    {
        $this->doctor = auth()->user();
        $this->loadDoctorData();
        $this->initializeSchedule();
    }

    public function loadDoctorData()
    {
        $this->name = $this->doctor->name;
        $this->email = $this->doctor->email;
        $this->phone = $this->doctor->phone;
        $this->specializations = $this->doctor->specializations ?? [];
        $this->contact_info = $this->doctor->contact_info ?? [];
    }

    public function initializeSchedule()
    {
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $this->weeklySchedule = [];

        foreach ($days as $day) {
            $this->weeklySchedule[$day] = [
                'is_working' => false,
                'start_time' => '09:00',
                'end_time' => '17:00',
                'break_start' => '13:00',
                'break_end' => '14:00',
            ];
        }
    }

    public function render()
    {
        $stats = $this->getDoctorStats();
        $earnings = $this->getEarningsBreakdown();
        $performance = $this->getPerformanceData();
        $upcomingAppointments = $this->getUpcomingAppointments();

        return view('livewire.doctor-profile', [
            'stats' => $stats,
            'earnings' => $earnings,
            'performance' => $performance,
            'upcomingAppointments' => $upcomingAppointments,
        ]);
    }

    public function getDoctorStats()
    {
        $doctorId = $this->doctor->id;
        
        return [
            'total_patients' => Treatment::where('doctor_id', $doctorId)
                ->distinct('patient_id')
                ->count(),
            'active_treatments' => Treatment::where('doctor_id', $doctorId)
                ->where('status', 'Active')
                ->count(),
            'completed_treatments' => Treatment::where('doctor_id', $doctorId)
                ->where('status', 'Completed')
                ->count(),
            'total_appointments' => Appointment::where('doctor_id', $doctorId)
                ->count(),
            'this_month_appointments' => Appointment::where('doctor_id', $doctorId)
                ->whereMonth('appointment_date', now()->month)
                ->count(),
        ];
    }

    public function getEarningsBreakdown()
    {
        $doctorId = $this->doctor->id;
        $commissionRate = $this->doctor->commission_rate;
        
        $treatments = Treatment::where('doctor_id', $doctorId)
            ->where('status', 'Completed')
            ->get();

        $earnings = [
            'consultations' => 0,
            'treatments' => 0,
            'total' => 0,
        ];

        foreach ($treatments as $treatment) {
            $commission = $treatment->cost * ($commissionRate / 100);
            $earnings['treatments'] += $commission;
            $earnings['total'] += $commission;
        }

        return $earnings;
    }

    public function getPerformanceData()
    {
        $doctorId = $this->doctor->id;
        
        // Get patient load for last 6 months
        $patientLoad = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $count = Treatment::where('doctor_id', $doctorId)
                ->whereMonth('created_at', $month->month)
                ->whereYear('created_at', $month->year)
                ->count();
            
            $patientLoad[] = [
                'month' => $month->format('M'),
                'count' => $count,
            ];
        }

        return [
            'patient_load' => $patientLoad,
            'treatment_success_rate' => $this->calculateTreatmentSuccessRate(),
            'patient_satisfaction' => $this->calculatePatientSatisfaction(),
        ];
    }

    public function getUpcomingAppointments()
    {
        return Appointment::with(['patient'])
            ->where('doctor_id', $this->doctor->id)
            ->where('appointment_date', '>', now())
            ->whereIn('status', ['Scheduled', 'Confirmed'])
            ->orderBy('appointment_date')
            ->take(5)
            ->get();
    }

    public function calculateTreatmentSuccessRate()
    {
        $doctorId = $this->doctor->id;
        $total = Treatment::where('doctor_id', $doctorId)->count();
        $completed = Treatment::where('doctor_id', $doctorId)
            ->where('status', 'Completed')
            ->count();

        return $total > 0 ? round(($completed / $total) * 100) : 0;
    }

    public function calculatePatientSatisfaction()
    {
        $doctorId = $this->doctor->id;
        $feedback = \App\Models\TreatmentFeedback::where('doctor_id', $doctorId)
            ->where('status', 'Submitted')
            ->get();

        if ($feedback->isEmpty()) return 0;

        return round($feedback->avg('rating'), 1);
    }

    public function editProfile()
    {
        $this->isEditing = true;
    }

    public function saveProfile()
    {
        $this->validate();

        // Handle photo upload
        if ($this->profile_photo) {
            $photoPath = $this->profile_photo->store('doctors/photos', 'public');
            $this->doctor->profile_photo = $photoPath;
        }

        $this->doctor->update([
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'specializations' => $this->specializations,
            'contact_info' => $this->contact_info,
        ]);

        $this->isEditing = false;
        session()->flash('message', 'Profile updated successfully!');
    }

    public function cancelEdit()
    {
        $this->isEditing = false;
        $this->loadDoctorData();
    }

    public function updateSchedule()
    {
        // Save schedule logic would go here
        session()->flash('message', 'Schedule updated successfully!');
    }

    public function requestPayout()
    {
        // Payout request logic would go here
        session()->flash('message', 'Payout request submitted successfully!');
    }

    public function getSpecializationTags()
    {
        return [
            'Panchakarma',
            'Ayurveda',
            'Yoga Therapy',
            'Herbal Medicine',
            'Diet Counseling',
            'Lifestyle Management',
            'Stress Management',
            'Detoxification',
        ];
    }
}