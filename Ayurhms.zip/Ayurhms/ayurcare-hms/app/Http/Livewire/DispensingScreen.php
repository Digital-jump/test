<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Prescription;
use App\Models\PrescriptionItem;
use App\Models\Medicine;
use App\Models\Patient;
use Livewire\WithPagination;

class DispensingScreen extends Component
{
    use WithPagination;

    public $search = '';
    public $filterStatus = '';
    public $selectedPrescription = null;
    public $showDispenseModal = false;
    public $dispenseItems = [];

    public function render()
    {
        $prescriptions = Prescription::with(['patient', 'doctor', 'items.medicine'])
            ->when($this->search, function($query) {
                $query->where(function($q) {
                    $q->whereHas('patient', function($q) {
                        $q->where('full_name', 'like', '%' . $this->search . '%')
                          ->orWhere('uhid', 'like', '%' . $this->search . '%');
                    });
                });
            })
            ->when($this->filterStatus, function($query) {
                $query->where('status', $this->filterStatus);
            })
            ->where('status', '!=', 'Cancelled')
            ->latest()
            ->paginate(10);

        return view('livewire.dispensing-screen', [
            'prescriptions' => $prescriptions,
        ]);
    }

    public function selectPrescription($prescriptionId)
    {
        $this->selectedPrescription = Prescription::with(['patient', 'doctor', 'items.medicine'])
            ->findOrFail($prescriptionId);
        
        $this->dispenseItems = $this->selectedPrescription->items
            ->where('dispensed', false)
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'medicine_id' => $item->medicine_id,
                    'medicine_name' => $item->medicine->name,
                    'dosage' => $item->dosage,
                    'frequency' => $item->frequency,
                    'duration' => $item->duration,
                    'duration_unit' => $item->duration_unit,
                    'quantity' => $item->quantity,
                    'batch_number' => $item->batch_number,
                    'price' => $item->price,
                    'instructions' => $item->instructions,
                    'available_stock' => $item->medicine->stock_quantity,
                    'can_dispense' => $item->canBeDispensed(),
                    'selected_batch' => $item->batch_number,
                ];
            })->toArray();

        $this->showDispenseModal = true;
    }

    public function dispenseMedicine()
    {
        if (!$this->selectedPrescription) {
            return;
        }

        $success = true;
        $failedItems = [];

        foreach ($this->dispenseItems as $item) {
            if ($item['can_dispense']) {
                $prescriptionItem = PrescriptionItem::find($item['id']);
                $medicine = Medicine::find($item['medicine_id']);
                
                // Update medicine stock
                $medicine->updateStock($item['quantity'], 'subtract');
                
                // Mark as dispensed
                $prescriptionItem->markAsDispensed(auth()->id());
            } else {
                $failedItems[] = $item['medicine_name'];
                $success = false;
            }
        }

        // Check if prescription is fully dispensed
        if ($this->selectedPrescription->isFullyDispensed()) {
            $this->selectedPrescription->markAsCompleted();
        }

        $this->showDispenseModal = false;
        $this->selectedPrescription = null;
        $this->dispenseItems = [];

        if ($success) {
            session()->flash('message', 'Medicines dispensed successfully!');
        } else {
            session()->flash('error', 'Some medicines could not be dispensed due to insufficient stock: ' . implode(', ', $failedItems));
        }
    }

    public function checkStock($medicineId, $quantity)
    {
        $medicine = Medicine::find($medicineId);
        return $medicine && $medicine->stock_quantity >= $quantity;
    }

    public function getPrescriptionStatusColor($status)
    {
        return match($status) {
            'Active' => 'blue',
            'Completed' => 'green',
            'Cancelled' => 'red',
            default => 'gray',
        };
    }

    public function getDispensedPercentage($prescription)
    {
        $totalItems = $prescription->getTotalItemsCount();
        $dispensedItems = $prescription->getDispensedItemsCount();
        
        return $totalItems > 0 ? round(($dispensedItems / $totalItems) * 100) : 0;
    }

    public function printPrescription($prescriptionId)
    {
        $prescription = Prescription::with(['patient', 'doctor', 'items.medicine'])
            ->findOrFail($prescriptionId);
        
        // This would generate a PDF or print view
        session()->flash('message', 'Print functionality would be implemented here');
    }
}