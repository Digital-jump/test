<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Medicine;
use Livewire\WithPagination;
use Livewire\WithFileUploads;

class MedicineInventory extends Component
{
    use WithPagination, WithFileUploads;

    public $search = '';
    public $filterType = '';
    public $filterStatus = '';
    public $showModal = false;
    public $editingMedicine;
    public $showLowStockOnly = false;

    // Form fields
    public $code;
    public $name;
    public $type;
    public $batch;
    public $mfg_date;
    public $exp_date;
    public $stock_quantity = 0;
    public $reorder_level = 10;
    public $price = 0;
    public $cost_price = 0;
    public $manufacturer;
    public $description;
    public $is_restricted = false;
    public $is_active = true;

    protected $rules = [
        'name' => 'required|string|min:3|max:255',
        'type' => 'required|string|min:3|max:255',
        'batch' => 'required|string|max:50',
        'mfg_date' => 'required|date|before:today',
        'exp_date' => 'required|date|after:today',
        'stock_quantity' => 'required|integer|min:0',
        'reorder_level' => 'required|integer|min:1',
        'price' => 'required|numeric|min:0',
        'cost_price' => 'required|numeric|min:0',
        'manufacturer' => 'nullable|string|max:255',
        'description' => 'nullable|string|max:1000',
        'is_restricted' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function mount()
    {
        $this->mfg_date = now()->subMonths(6)->format('Y-m-d');
        $this->exp_date = now()->addYears(2)->format('Y-m-d');
    }

    public function render()
    {
        $query = Medicine::when($this->search, function($query) {
                $query->where(function($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                      ->orWhere('code', 'like', '%' . $this->search . '%')
                      ->orWhere('batch', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->filterType, function($query) {
                $query->where('type', $this->filterType);
            })
            ->when($this->filterStatus, function($query) {
                switch($this->filterStatus) {
                    case 'low_stock':
                        $query->where('stock_quantity', '<=', \DB::raw('reorder_level'));
                        break;
                    case 'expiring_soon':
                        $query->where('exp_date', '<=', now()->addMonths(3));
                        break;
                    case 'expired':
                        $query->where('exp_date', '<', now());
                        break;
                }
            })
            ->when($this->showLowStockOnly, function($query) {
                $query->where('stock_quantity', '<=', \DB::raw('reorder_level'));
            })
            ->latest();

        $medicines = $query->paginate(15);
        
        $stats = [
            'total_medicines' => Medicine::count(),
            'low_stock_count' => Medicine::where('stock_quantity', '<=', \DB::raw('reorder_level'))->count(),
            'expiring_soon_count' => Medicine::where('exp_date', '<=', now()->addMonths(3))->count(),
            'expired_count' => Medicine::where('exp_date', '<', now())->count(),
        ];

        return view('livewire.medicine-inventory', [
            'medicines' => $medicines,
            'stats' => $stats,
        ]);
    }

    public function create()
    {
        $this->resetForm();
        $this->code = Medicine::generateCode();
        $this->showModal = true;
    }

    public function edit($id)
    {
        $this->editingMedicine = Medicine::findOrFail($id);
        $this->code = $this->editingMedicine->code;
        $this->name = $this->editingMedicine->name;
        $this->type = $this->editingMedicine->type;
        $this->batch = $this->editingMedicine->batch;
        $this->mfg_date = $this->editingMedicine->mfg_date->format('Y-m-d');
        $this->exp_date = $this->editingMedicine->exp_date->format('Y-m-d');
        $this->stock_quantity = $this->editingMedicine->stock_quantity;
        $this->reorder_level = $this->editingMedicine->reorder_level;
        $this->price = $this->editingMedicine->price;
        $this->cost_price = $this->editingMedicine->cost_price;
        $this->manufacturer = $this->editingMedicine->manufacturer;
        $this->description = $this->editingMedicine->description;
        $this->is_restricted = $this->editingMedicine->is_restricted;
        $this->is_active = $this->editingMedicine->is_active;
        $this->showModal = true;
    }

    public function save()
    {
        $this->validate();

        if ($this->editingMedicine) {
            $this->editingMedicine->update([
                'name' => $this->name,
                'type' => $this->type,
                'batch' => $this->batch,
                'mfg_date' => $this->mfg_date,
                'exp_date' => $this->exp_date,
                'stock_quantity' => $this->stock_quantity,
                'reorder_level' => $this->reorder_level,
                'price' => $this->price,
                'cost_price' => $this->cost_price,
                'manufacturer' => $this->manufacturer,
                'description' => $this->description,
                'is_restricted' => $this->is_restricted,
                'is_active' => $this->is_active,
            ]);

            session()->flash('message', 'Medicine updated successfully!');
        } else {
            Medicine::create([
                'code' => $this->code,
                'name' => $this->name,
                'type' => $this->type,
                'batch' => $this->batch,
                'mfg_date' => $this->mfg_date,
                'exp_date' => $this->exp_date,
                'stock_quantity' => $this->stock_quantity,
                'reorder_level' => $this->reorder_level,
                'price' => $this->price,
                'cost_price' => $this->cost_price,
                'manufacturer' => $this->manufacturer,
                'description' => $this->description,
                'is_restricted' => $this->is_restricted,
                'is_active' => $this->is_active,
            ]);

            session()->flash('message', 'Medicine created successfully!');
        }

        $this->resetForm();
        $this->showModal = false;
    }

    public function delete($id)
    {
        $medicine = Medicine::findOrFail($id);
        $medicine->delete();
        session()->flash('message', 'Medicine deleted successfully!');
    }

    public function resetForm()
    {
        $this->reset([
            'code', 'name', 'type', 'batch', 'mfg_date', 'exp_date',
            'stock_quantity', 'reorder_level', 'price', 'cost_price',
            'manufacturer', 'description', 'is_restricted', 'is_active', 'editingMedicine'
        ]);
        $this->mfg_date = now()->subMonths(6)->format('Y-m-d');
        $this->exp_date = now()->addYears(2)->format('Y-m-d');
    }

    public function getStockStatus($medicine)
    {
        return $medicine->stock_status;
    }

    public function getStockStatusColor($medicine)
    {
        return $medicine->stock_status_color;
    }

    public function reorder($id)
    {
        $medicine = Medicine::findOrFail($id);
        // This would typically open a purchase order form
        session()->flash('message', 'Reorder process initiated for ' . $medicine->name);
    }

    public function export()
    {
        // This would trigger an export functionality
        session()->flash('message', 'Export functionality would be implemented here');
    }
}