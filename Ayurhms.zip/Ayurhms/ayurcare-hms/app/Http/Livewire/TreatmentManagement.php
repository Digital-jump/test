<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Treatment;
use App\Models\Patient;
use App\Models\User;
use Livewire\WithPagination;

class TreatmentManagement extends Component
{
    use WithPagination;

    public $search = '';
    public $filterStatus = '';
    public $filterDoctor = '';
    public $showModal = false;
    public $showDetailModal = false;
    public $selectedTreatment;
    public $editingTreatment;

    // Form fields
    public $patient_id;
    public $doctor_id;
    public $name;
    public $type;
    public $start_date;
    public $end_date;
    public $status = 'Active';
    public $room;
    public $notes;
    public $cost = 0;

    protected $rules = [
        'patient_id' => 'required|exists:patients,id',
        'doctor_id' => 'required|exists:users,id',
        'name' => 'required|string|min:3|max:255',
        'type' => 'required|string|min:3|max:255',
        'start_date' => 'required|date',
        'end_date' => 'required|date|after:start_date',
        'status' => 'required|in:Active,Completed,Cancelled',
        'room' => 'nullable|string|max:50',
        'notes' => 'nullable|string|max:1000',
        'cost' => 'required|numeric|min:0',
    ];

    public function mount()
    {
        $this->start_date = now()->format('Y-m-d');
        $this->end_date = now()->addDays(7)->format('Y-m-d');
    }

    public function render()
    {
        $query = Treatment::with(['patient', 'doctor'])
            ->when($this->search, function($query) {
                $query->where(function($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                      ->orWhereHas('patient', function($q) {
                          $q->where('full_name', 'like', '%' . $this->search . '%')
                            ->orWhere('uhid', 'like', '%' . $this->search . '%');
                      });
                });
            })
            ->when($this->filterStatus, function($query) {
                $query->where('status', $this->filterStatus);
            })
            ->when($this->filterDoctor, function($query) {
                $query->where('doctor_id', $this->filterDoctor);
            })
            ->latest();

        $treatments = $query->paginate(10);
        $patients = Patient::where('is_active', true)->get();
        $doctors = User::where('role', 'doctor')->where('is_active', true)->get();

        return view('livewire.treatment-management', [
            'treatments' => $treatments,
            'patients' => $patients,
            'doctors' => $doctors,
        ]);
    }

    public function create()
    {
        $this->resetForm();
        $this->showModal = true;
    }

    public function edit($id)
    {
        $this->editingTreatment = Treatment::findOrFail($id);
        $this->patient_id = $this->editingTreatment->patient_id;
        $this->doctor_id = $this->editingTreatment->doctor_id;
        $this->name = $this->editingTreatment->name;
        $this->type = $this->editingTreatment->type;
        $this->start_date = $this->editingTreatment->start_date->format('Y-m-d');
        $this->end_date = $this->editingTreatment->end_date->format('Y-m-d');
        $this->status = $this->editingTreatment->status;
        $this->room = $this->editingTreatment->room;
        $this->notes = $this->editingTreatment->notes;
        $this->cost = $this->editingTreatment->cost;
        $this->showModal = true;
    }

    public function showDetails($id)
    {
        $this->selectedTreatment = Treatment::with(['patient', 'doctor', 'prescriptions', 'feedback'])->findOrFail($id);
        $this->showDetailModal = true;
    }

    public function save()
    {
        $this->validate();

        if ($this->editingTreatment) {
            $this->editingTreatment->update([
                'patient_id' => $this->patient_id,
                'doctor_id' => $this->doctor_id,
                'name' => $this->name,
                'type' => $this->type,
                'start_date' => $this->start_date,
                'end_date' => $this->end_date,
                'status' => $this->status,
                'room' => $this->room,
                'notes' => $this->notes,
                'cost' => $this->cost,
            ]);

            session()->flash('message', 'Treatment updated successfully!');
        } else {
            Treatment::create([
                'patient_id' => $this->patient_id,
                'doctor_id' => $this->doctor_id,
                'name' => $this->name,
                'type' => $this->type,
                'start_date' => $this->start_date,
                'end_date' => $this->end_date,
                'status' => $this->status,
                'room' => $this->room,
                'notes' => $this->notes,
                'cost' => $this->cost,
            ]);

            session()->flash('message', 'Treatment created successfully!');
        }

        $this->resetForm();
        $this->showModal = false;
    }

    public function markAsCompleted($id)
    {
        $treatment = Treatment::findOrFail($id);
        $treatment->markAsCompleted();
        session()->flash('message', 'Treatment marked as completed!');
    }

    public function cancel($id)
    {
        $treatment = Treatment::findOrFail($id);
        $treatment->cancel();
        session()->flash('message', 'Treatment cancelled!');
    }

    public function resetForm()
    {
        $this->reset([
            'patient_id', 'doctor_id', 'name', 'type', 'start_date', 
            'end_date', 'status', 'room', 'notes', 'cost', 'editingTreatment'
        ]);
        $this->start_date = now()->format('Y-m-d');
        $this->end_date = now()->addDays(7)->format('Y-m-d');
    }

    public function getStatusColor($status)
    {
        return match($status) {
            'Active' => 'green',
            'Completed' => 'blue',
            'Cancelled' => 'red',
            default => 'gray',
        };
    }

    public function getProgressPercentage($treatment)
    {
        return $treatment->getProgressPercentage();
    }

    public function getDaysRemaining($treatment)
    {
        return $treatment->getDaysRemaining();
    }
}