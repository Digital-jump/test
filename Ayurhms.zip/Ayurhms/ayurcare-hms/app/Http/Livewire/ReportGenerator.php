<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Patient;
use App\Models\Treatment;
use App\Models\Transaction;
use App\Models\Medicine;
use App\Models\Appointment;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ReportExport;

class ReportGenerator extends Component
{
    public $reportType = 'patient';
    public $dateRange = 'this_month';
    public $customStartDate;
    public $customEndDate;
    public $filters = [];
    public $outputFormat = 'html';
    public $reportData = [];
    public $showPreview = false;

    protected $rules = [
        'reportType' => 'required|in:patient,revenue,inventory,appointment,treatment',
        'dateRange' => 'required|in:today,this_week,this_month,last_month,custom',
        'customStartDate' => 'required_if:dateRange,custom|date',
        'customEndDate' => 'required_if:dateRange,custom|date|after_or_equal:customStartDate',
        'outputFormat' => 'required|in:html,pdf,excel',
    ];

    public function render()
    {
        return view('livewire.report-generator');
    }

    public function generateReport()
    {
        $this->validate();
        
        $dates = $this->getDateRange();
        $this->reportData = $this->fetchReportData($dates);
        $this->showPreview = true;
    }

    public function getDateRange()
    {
        switch ($this->dateRange) {
            case 'today':
                return [
                    'start' => now()->startOfDay(),
                    'end' => now()->endOfDay(),
                ];
            case 'this_week':
                return [
                    'start' => now()->startOfWeek(),
                    'end' => now()->endOfWeek(),
                ];
            case 'this_month':
                return [
                    'start' => now()->startOfMonth(),
                    'end' => now()->endOfMonth(),
                ];
            case 'last_month':
                return [
                    'start' => now()->subMonth()->startOfMonth(),
                    'end' => now()->subMonth()->endOfMonth(),
                ];
            case 'custom':
                return [
                    'start' => Carbon::parse($this->customStartDate)->startOfDay(),
                    'end' => Carbon::parse($this->customEndDate)->endOfDay(),
                ];
            default:
                return [
                    'start' => now()->startOfMonth(),
                    'end' => now()->endOfMonth(),
                ];
        }
    }

    public function fetchReportData($dates)
    {
        switch ($this->reportType) {
            case 'patient':
                return $this->generatePatientReport($dates);
            case 'revenue':
                return $this->generateRevenueReport($dates);
            case 'inventory':
                return $this->generateInventoryReport($dates);
            case 'appointment':
                return $this->generateAppointmentReport($dates);
            case 'treatment':
                return $this->generateTreatmentReport($dates);
            default:
                return [];
        }
    }

    public function generatePatientReport($dates)
    {
        $query = Patient::query();

        if (isset($this->filters['gender'])) {
            $query->where('gender', $this->filters['gender']);
        }

        if (isset($this->filters['registration_type'])) {
            $query->whereJsonContains('ayurvedic_info->registration_type', $this->filters['registration_type']);
        }

        $patients = $query->whereBetween('created_at', [$dates['start'], $dates['end']])
            ->withCount(['treatments', 'appointments'])
            ->get();

        return [
            'title' => 'Patient Registration Report',
            'period' => $dates['start']->format('M d, Y') . ' - ' . $dates['end']->format('M d, Y'),
            'summary' => [
                'total_patients' => $patients->count(),
                'male_patients' => $patients->where('gender', 'Male')->count(),
                'female_patients' => $patients->where('gender', 'Female')->count(),
                'other_patients' => $patients->where('gender', 'Other')->count(),
                'opd_patients' => $patients->filter(function($p) {
                    return data_get($p->ayurvedic_info, 'registration_type') === 'OPD';
                })->count(),
                'ipd_patients' => $patients->filter(function($p) {
                    return data_get($p->ayurvedic_info, 'registration_type') === 'IPD';
                })->count(),
            ],
            'data' => $patients->map(function($patient) {
                return [
                    'UHID' => $patient->uhid,
                    'Name' => $patient->full_name,
                    'Gender' => $patient->gender,
                    'Age' => $patient->age,
                    'Registration Type' => data_get($patient->ayurvedic_info, 'registration_type'),
                    'Treatments' => $patient->treatments_count,
                    'Appointments' => $patient->appointments_count,
                    'Registered Date' => $patient->created_at->format('M d, Y'),
                ];
            })->toArray(),
        ];
    }

    public function generateRevenueReport($dates)
    {
        $transactions = Transaction::whereBetween('created_at', [$dates['start'], $dates['end']])
            ->with(['patient'])
            ->get();

        return [
            'title' => 'Revenue Report',
            'period' => $dates['start']->format('M d, Y') . ' - ' . $dates['end']->format('M d, Y'),
            'summary' => [
                'total_transactions' => $transactions->count(),
                'paid_transactions' => $transactions->where('status', 'Paid')->count(),
                'pending_transactions' => $transactions->where('status', 'Pending')->count(),
                'total_revenue' => $transactions->where('status', 'Paid')->sum('total'),
                'average_transaction' => $transactions->where('status', 'Paid')->avg('total'),
                'cash_payments' => $transactions->where('status', 'Paid')->where('payment_method', 'Cash')->count(),
                'upi_payments' => $transactions->where('status', 'Paid')->where('payment_method', 'UPI')->count(),
                'card_payments' => $transactions->where('status', 'Paid')->where('payment_method', 'Card')->count(),
            ],
            'data' => $transactions->map(function($transaction) {
                return [
                    'Invoice Number' => $transaction->invoice_number,
                    'Patient' => $transaction->patient->full_name,
                    'UHID' => $transaction->patient->uhid,
                    'Amount' => $transaction->total,
                    'Payment Method' => $transaction->payment_method,
                    'Status' => $transaction->status,
                    'Date' => $transaction->created_at->format('M d, Y'),
                ];
            })->toArray(),
        ];
    }

    public function generateInventoryReport($dates)
    {
        $medicines = Medicine::withCount(['prescriptionItems' => function($query) use ($dates) {
            $query->whereBetween('created_at', [$dates['start'], $dates['end']]);
        }])->get();

        return [
            'title' => 'Inventory Report',
            'period' => $dates['start']->format('M d, Y') . ' - ' . $dates['end']->format('M d, Y'),
            'summary' => [
                'total_medicines' => $medicines->count(),
                'low_stock_items' => $medicines->where('stock_quantity', '<=', \DB::raw('reorder_level'))->count(),
                'expiring_soon' => $medicines->where('exp_date', '<=', now()->addMonths(3))->count(),
                'expired_items' => $medicines->where('exp_date', '<', now())->count(),
                'total_stock_value' => $medicines->sum('stock_quantity') * $medicines->avg('cost_price'),
                'most_dispensed' => $medicines->sortByDesc('prescription_items_count')->take(5)->pluck('name')->toArray(),
            ],
            'data' => $medicines->map(function($medicine) {
                return [
                    'Code' => $medicine->code,
                    'Name' => $medicine->name,
                    'Type' => $medicine->type,
                    'Stock Quantity' => $medicine->stock_quantity,
                    'Reorder Level' => $medicine->reorder_level,
                    'Price' => $medicine->price,
                    'Cost Price' => $medicine->cost_price,
                    'Expiry Date' => $medicine->exp_date->format('M d, Y'),
                    'Status' => $medicine->stock_status,
                    'Dispensed This Period' => $medicine->prescription_items_count,
                ];
            })->toArray(),
        ];
    }

    public function generateAppointmentReport($dates)
    {
        $appointments = Appointment::whereBetween('appointment_date', [$dates['start'], $dates['end']])
            ->with(['patient', 'doctor'])
            ->get();

        return [
            'title' => 'Appointment Report',
            'period' => $dates['start']->format('M d, Y') . ' - ' . $dates['end']->format('M d, Y'),
            'summary' => [
                'total_appointments' => $appointments->count(),
                'completed_appointments' => $appointments->where('status', 'Completed')->count(),
                'cancelled_appointments' => $appointments->where('status', 'Cancelled')->count(),
                'no_show_appointments' => $appointments->where('status', 'No Show')->count(),
                'total_revenue' => $appointments->where('status', 'Completed')->sum('fee'),
                'show_rate' => $appointments->count() > 0 ? 
                    round(($appointments->whereIn('status', ['Completed', 'In Progress'])->count() / $appointments->count()) * 100, 2) : 0,
            ],
            'data' => $appointments->map(function($appointment) {
                return [
                    'Patient' => $appointment->patient->full_name,
                    'UHID' => $appointment->patient->uhid,
                    'Doctor' => $appointment->doctor->name,
                    'Date' => $appointment->appointment_date->format('M d, Y'),
                    'Time' => $appointment->appointment_date->format('h:i A'),
                    'Status' => $appointment->status,
                    'Fee' => $appointment->fee,
                    'Reason' => $appointment->reason,
                ];
            })->toArray(),
        ];
    }

    public function generateTreatmentReport($dates)
    {
        $treatments = Treatment::whereBetween('created_at', [$dates['start'], $dates['end']])
            ->with(['patient', 'doctor'])
            ->get();

        return [
            'title' => 'Treatment Report',
            'period' => $dates['start']->format('M d, Y') . ' - ' . $dates['end']->format('M d, Y'),
            'summary' => [
                'total_treatments' => $treatments->count(),
                'active_treatments' => $treatments->where('status', 'Active')->count(),
                'completed_treatments' => $treatments->where('status', 'Completed')->count(),
                'cancelled_treatments' => $treatments->where('status', 'Cancelled')->count(),
                'total_revenue' => $treatments->sum('cost'),
                'average_treatment_cost' => $treatments->avg('cost'),
                'most_common_treatment' => $treatments->groupBy('type')->map->count()->sortDesc()->first(),
            ],
            'data' => $treatments->map(function($treatment) {
                return [
                    'Patient' => $treatment->patient->full_name,
                    'UHID' => $treatment->patient->uhid,
                    'Doctor' => $treatment->doctor->name,
                    'Treatment Name' => $treatment->name,
                    'Type' => $treatment->type,
                    'Start Date' => $treatment->start_date->format('M d, Y'),
                    'End Date' => $treatment->end_date->format('M d, Y'),
                    'Status' => $treatment->status,
                    'Cost' => $treatment->cost,
                    'Progress' => $treatment->getProgressPercentage() . '%',
                ];
            })->toArray(),
        ];
    }

    public function exportReport()
    {
        if (empty($this->reportData)) {
            session()->flash('error', 'Please generate the report first');
            return;
        }

        $filename = $this->reportType . '_report_' . now()->format('Y_m_d_H_i_s');

        switch ($this->outputFormat) {
            case 'excel':
                return Excel::download(new ReportExport($this->reportData), $filename . '.xlsx');
            case 'pdf':
                // PDF export logic would go here
                session()->flash('message', 'PDF export functionality would be implemented here');
                break;
            case 'html':
                // HTML is already shown in preview
                session()->flash('message', 'Report is ready for viewing');
                break;
        }
    }

    public function resetFilters()
    {
        $this->reset(['filters', 'customStartDate', 'customEndDate', 'dateRange']);
        $this->dateRange = 'this_month';
        $this->showPreview = false;
        $this->reportData = [];
    }
}