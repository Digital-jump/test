<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Treatment extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'patient_id',
        'doctor_id',
        'name',
        'type',
        'start_date',
        'end_date',
        'status',
        'room',
        'notes',
        'schedule_options',
        'cost',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'schedule_options' => 'array',
        'cost' => 'decimal:2',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function prescriptions()
    {
        return $this->hasMany(Prescription::class);
    }

    public function feedback()
    {
        return $this->hasMany(TreatmentFeedback::class);
    }

    public function getProgressPercentage()
    {
        if ($this->status === 'Completed') return 100;
        if ($this->status === 'Cancelled') return 0;

        $totalDays = Carbon::parse($this->start_date)->diffInDays($this->end_date) + 1;
        $elapsedDays = Carbon::parse($this->start_date)->diffInDays(now()) + 1;

        return min(max(round(($elapsedDays / $totalDays) * 100), 0), 100);
    }

    public function getDaysRemaining()
    {
        if ($this->status === 'Completed') return 0;
        
        $remaining = Carbon::now()->diffInDays($this->end_date, false);
        return max($remaining, 0);
    }

    public function isNearCompletion()
    {
        return $this->getDaysRemaining() <= 3 && $this->status === 'Active';
    }

    public function markAsCompleted()
    {
        $this->status = 'Completed';
        $this->save();
    }

    public function cancel()
    {
        $this->status = 'Cancelled';
        $this->save();
    }
}