<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Transaction extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'patient_id',
        'invoice_number',
        'subtotal',
        'discount',
        'tax',
        'total',
        'payment_method',
        'status',
        'items',
        'notes',
        'created_by',
    ];

    protected $casts = [
        'subtotal' => 'decimal:2',
        'discount' => 'decimal:2',
        'tax' => 'decimal:2',
        'total' => 'decimal:2',
        'items' => 'array',
    ];

    public static function generateInvoiceNumber()
    {
        $prefix = 'INV';
        $year = date('Y');
        $month = date('m');
        
        $lastTransaction = self::where('invoice_number', 'like', $prefix . '-' . $year . $ . '%')
            ->orderBy('invoice_number', 'desc')
            ->first();

        if ($lastTransaction) {
            $lastNumber = intval(substr($lastTransaction->invoice_number, -6));
            $newNumber = str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '000001';
        }

        return $prefix . '-' . $year . $month . '-' . $newNumber;
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function markAsPaid()
    {
        $this->status = 'Paid';
        $this->save();
    }

    public function cancel()
    {
        $this->status = 'Cancelled';
        $this->save();
    }

    public function refund()
    {
        $this->status = 'Refunded';
        $this->save();
    }

    public function calculateTax()
    {
        // Assuming 18% GST
        return $this->subtotal * 0.18;
    }

    public function calculateTotal()
    {
        return $this->subtotal - $this->discount + $this->tax;
    }

    public function updateTotals()
    {
        $this->tax = $this->calculateTax();
        $this->total = $this->calculateTotal();
        $this->save();
    }
}