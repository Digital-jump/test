<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TreatmentFeedback extends Model
{
    use HasFactory;

    protected $fillable = [
        'treatment_id',
        'patient_id',
        'doctor_id',
        'rating',
        'feedback',
        'recommendations',
        'status',
    ];

    protected $casts = [
        'rating' => 'integer',
        'status' => 'string',
    ];

    public function treatment()
    {
        return $this->belongsTo(Treatment::class);
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function submit()
    {
        $this->status = 'Submitted';
        $this->save();
    }

    public function markAsReviewed()
    {
        $this->status = 'Reviewed';
        $this->save();
    }

    public function getStarRatingAttribute()
    {
        $stars = '';
        for ($i = 1; $i <= 5; $i++) {
            $stars .= $i <= $this->rating ? '★' : '☆';
        }
        return $stars;
    }
}