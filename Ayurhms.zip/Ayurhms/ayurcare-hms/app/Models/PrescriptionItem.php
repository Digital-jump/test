<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PrescriptionItem extends Model
{
    use HasFactory;

    protected $fillable = [
        'prescription_id',
        'medicine_id',
        'dosage',
        'frequency',
        'duration',
        'duration_unit',
        'quantity',
        'batch_number',
        'price',
        'instructions',
        'dispensed',
        'dispensed_at',
        'dispensed_by',
    ];

    protected $casts = [
        'dispensed' => 'boolean',
        'dispensed_at' => 'datetime',
        'price' => 'decimal:2',
    ];

    public function prescription()
    {
        return $this->belongsTo(Prescription::class);
    }

    public function medicine()
    {
        return $this->belongsTo(Medicine::class);
    }

    public function dispenser()
    {
        return $this->belongsTo(User::class, 'dispensed_by');
    }

    public function markAsDispensed($dispensedBy)
    {
        $this->dispensed = true;
        $this->dispensed_at = now();
        $this->dispensed_by = $dispensedBy;
        $this->save();
    }

    public function canBeDispensed()
    {
        if ($this->dispensed) return false;
        
        $medicine = $this->medicine;
        if (!$medicine || $medicine->stock_quantity < $this->quantity) {
            return false;
        }

        return true;
    }
}