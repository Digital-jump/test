<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Patient extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'uhid',
        'full_name',
        'gender',
        'date_of_birth',
        'age',
        'aadhaar_number',
        'contact_info',
        'ayurvedic_info',
        'photo',
        'is_active',
    ];

    protected $casts = [
        'date_of_birth' => 'date',
        'age' => 'integer',
        'contact_info' => 'array',
        'ayurvedic_info' => 'array',
        'is_active' => 'boolean',
    ];

    public static function generateUhid()
    {
        $year = date('Y');
        $lastPatient = self::where('uhid', 'like', 'AYR-' . $year . '%')
            ->orderBy('uhid', 'desc')
            ->first();

        if ($lastPatient) {
            $lastNumber = intval(substr($lastPatient->uhid, -4));
            $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '0001';
        }

        return 'AYR-' . $year . '-' . $newNumber;
    }

    public function setAgeAttribute()
    {
        $this->attributes['age'] = Carbon::parse($this->date_of_birth)->age;
    }

    public function getMaskedAadhaarAttribute()
    {
        if (!$this->aadhaar_number) return null;
        
        $aadhaar = str_replace('-', '', $this->aadhaar_number);
        if (strlen($aadhaar) !== 12) return $this->aadhaar_number;
        
        return substr($aadhaar, 0, 4) . '-' . substr($aadhaar, 4, 4) . '-' . substr($aadhaar, 8, 4);
    }

    public function treatments()
    {
        return $this->hasMany(Treatment::class);
    }

    public function appointments()
    {
        return $this->hasMany(Appointment::class);
    }

    public function prescriptions()
    {
        return $this->hasMany(Prescription::class);
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function feedback()
    {
        return $this->hasMany(TreatmentFeedback::class);
    }

    public function getOngoingTreatments()
    {
        return $this->treatments()->where('status', 'Active')->get();
    }

    public function getUpcomingAppointments()
    {
        return $this->appointments()
            ->where('appointment_date', '>', now())
            ->whereIn('status', ['Scheduled', 'Confirmed'])
            ->orderBy('appointment_date')
            ->get();
    }

    public function getActivePrescriptions()
    {
        return $this->prescriptions()
            ->where('status', 'Active')
            ->get();
    }

    public function getPendingFeedback()
    {
        return $this->feedback()
            ->where('status', 'Pending')
            ->get();
    }
}