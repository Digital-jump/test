<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Medicine extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'code',
        'name',
        'type',
        'batch',
        'mfg_date',
        'exp_date',
        'stock_quantity',
        'reorder_level',
        'price',
        'cost_price',
        'manufacturer',
        'description',
        'is_restricted',
        'is_active',
    ];

    protected $casts = [
        'mfg_date' => 'date',
        'exp_date' => 'date',
        'stock_quantity' => 'integer',
        'reorder_level' => 'integer',
        'price' => 'decimal:2',
        'cost_price' => 'decimal:2',
        'is_restricted' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function prescriptionItems()
    {
        return $this->hasMany(PrescriptionItem::class);
    }

    public function isLowStock()
    {
        return $this->stock_quantity <= $this->reorder_level;
    }

    public function isExpiringSoon()
    {
        return Carbon::now()->addMonths(3)->gte($this->exp_date);
    }

    public function isExpired()
    {
        return Carbon::now()->gt($this->exp_date);
    }

    public function getStockStatusAttribute()
    {
        if ($this->isExpired()) return 'Expired';
        if ($this->isExpiringSoon()) return 'Expiring Soon';
        if ($this->isLowStock()) return 'Low Stock';
        return 'In Stock';
    }

    public function getStockStatusColorAttribute()
    {
        switch ($this->stock_status) {
            case 'Expired': return 'red';
            case 'Expiring Soon': return 'orange';
            case 'Low Stock': return 'yellow';
            default: return 'green';
        }
    }

    public function updateStock($quantity, $operation = 'subtract')
    {
        if ($operation === 'subtract') {
            $this->stock_quantity -= $quantity;
        } else {
            $this->stock_quantity += $quantity;
        }
        
        $this->save();
    }

    public static function generateCode()
    {
        $prefix = 'MED';
        $lastMedicine = self::orderBy('code', 'desc')->first();
        
        if ($lastMedicine) {
            $lastNumber = intval(substr($lastMedicine->code, -6));
            $newNumber = str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);
        } else {
            $newNumber = '000001';
        }

        return $prefix . $newNumber;
    }
}