<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Prescription extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'patient_id',
        'doctor_id',
        'treatment_id',
        'diagnosis',
        'notes',
        'status',
    ];

    protected $casts = [
        'status' => 'string',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function treatment()
    {
        return $this->belongsTo(Treatment::class);
    }

    public function items()
    {
        return $this->hasMany(PrescriptionItem::class);
    }

    public function getTotalCostAttribute()
    {
        return $this->items()->sum('price');
    }

    public function getDispensedItemsCount()
    {
        return $this->items()->where('dispensed', true)->count();
    }

    public function getTotalItemsCount()
    {
        return $this->items()->count();
    }

    public function isFullyDispensed()
    {
        return $this->getDispensedItemsCount() === $this->getTotalItemsCount();
    }

    public function markAsCompleted()
    {
        $this->status = 'Completed';
        $this->save();
    }

    public function cancel()
    {
        $this->status = 'Cancelled';
        $this->save();
    }
}