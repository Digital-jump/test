<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Appointment extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'patient_id',
        'doctor_id',
        'appointment_date',
        'status',
        'reason',
        'notes',
        'fee',
        'is_reminder_sent',
    ];

    protected $casts = [
        'appointment_date' => 'datetime',
        'fee' => 'decimal:2',
        'is_reminder_sent' => 'boolean',
    ];

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function isUpcoming()
    {
        return $this->appointment_date > now() && in_array($this->status, ['Scheduled', 'Confirmed']);
    }

    public function isToday()
    {
        return $this->appointment_date->isToday();
    }

    public function isOverdue()
    {
        return $this->appointment_date < now() && $this->status === 'Scheduled';
    }

    public function canBeCancelled()
    {
        return in_array($this->status, ['Scheduled', 'Confirmed']) && 
               $this->appointment_date->diffInHours(now()) > 24;
    }

    public function confirm()
    {
        $this->status = 'Confirmed';
        $this->save();
    }

    public function start()
    {
        $this->status = 'In Progress';
        $this->save();
    }

    public function complete()
    {
        $this->status = 'Completed';
        $this->save();
    }

    public function cancel()
    {
        $this->status = 'Cancelled';
        $this->save();
    }

    public function markAsNoShow()
    {
        $this->status = 'No Show';
        $this->save();
    }

    public function getFormattedDateAttribute()
    {
        return $this->appointment_date->format('d M Y');
    }

    public function getFormattedTimeAttribute()
    {
        return $this->appointment_date->format('h:i A');
    }

    public function getStatusColorAttribute()
    {
        switch ($this->status) {
            case 'Scheduled': return 'gray';
            case 'Confirmed': return 'blue';
            case 'In Progress': return 'yellow';
            case 'Completed': return 'green';
            case 'Cancelled': return 'red';
            case 'No Show': return 'orange';
            default: return 'gray';
        }
    }
}