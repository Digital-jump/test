<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'AyurCare HMS - Ayurvedic Hospital Management System')</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Livewire Styles -->
    @livewireStyles
    
    <!-- Custom Styles -->
    <style>
        .sidebar-link {
            @apply flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors duration-200;
        }
        .sidebar-link.active {
            @apply bg-blue-50 text-blue-700 border-r-2 border-blue-700;
        }
        .card {
            @apply bg-white rounded-lg shadow-md border border-gray-200;
        }
        .btn {
            @apply px-4 py-2 rounded-md font-medium transition-colors duration-200;
        }
        .btn-primary {
            @apply bg-blue-600 text-white hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2;
        }
        .btn-secondary {
            @apply bg-gray-600 text-white hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2;
        }
        .btn-success {
            @apply bg-green-600 text-white hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2;
        }
        .btn-danger {
            @apply bg-red-600 text-white hover:bg-red-700 focus:ring-2 focus:ring-red-500 focus:ring-offset-2;
        }
        .btn-warning {
            @apply bg-yellow-600 text-white hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Main Container -->
    <div class="flex h-screen">
        <!-- Sidebar -->
        @auth
        <div class="w-64 bg-white shadow-lg">
            <div class="p-6 border-b border-gray-200">
                <h1 class="text-xl font-bold text-gray-800">AyurCare HMS</h1>
                <p class="text-sm text-gray-600">{{ auth()->user()->name }}</p>
                <p class="text-xs text-gray-500">{{ ucfirst(auth()->user()->role) }}</p>
            </div>
            
            <nav class="mt-6">
                <a href="{{ route('dashboard') }}" class="sidebar-link {{ request()->is('dashboard') ? 'active' : '' }}">
                    <i class="fas fa-home w-5 mr-3"></i>
                    Dashboard
                </a>
                
                @role('admin')
                    <a href="{{ route('admin.dashboard') }}" class="sidebar-link {{ request()->is('admin/*') ? 'active' : '' }}">
                        <i class="fas fa-tachometer-alt w-5 mr-3"></i>
                        Admin Dashboard
                    </a>
                    <a href="{{ route('admin.users') }}" class="sidebar-link">
                        <i class="fas fa-users w-5 mr-3"></i>
                        Users
                    </a>
                    <a href="{{ route('admin.reports') }}" class="sidebar-link">
                        <i class="fas fa-chart-bar w-5 mr-3"></i>
                        Reports
                    </a>
                @endrole
                
                @role('doctor')
                    <a href="{{ route('doctor.dashboard') }}" class="sidebar-link {{ request()->is('doctor/*') ? 'active' : '' }}">
                        <i class="fas fa-user-md w-5 mr-3"></i>
                        Doctor Dashboard
                    </a>
                    <a href="{{ route('doctor.profile') }}" class="sidebar-link">
                        <i class="fas fa-id-card w-5 mr-3"></i>
                        My Profile
                    </a>
                    <a href="{{ route('doctor.patients') }}" class="sidebar-link">
                        <i class="fas fa-users w-5 mr-3"></i>
                        Patients
                    </a>
                    <a href="{{ route('doctor.treatments') }}" class="sidebar-link">
                        <i class="fas fa-procedures w-5 mr-3"></i>
                        Treatments
                    </a>
                    <a href="{{ route('doctor.appointments') }}" class="sidebar-link">
                        <i class="fas fa-calendar w-5 mr-3"></i>
                        Appointments
                    </a>
                @endrole
                
                @role('pharmacy')
                    <a href="{{ route('pharmacy.dashboard') }}" class="sidebar-link {{ request()->is('pharmacy/*') ? 'active' : '' }}">
                        <i class="fas fa-pills w-5 mr-3"></i>
                        Pharmacy Dashboard
                    </a>
                    <a href="{{ route('pharmacy.inventory') }}" class="sidebar-link">
                        <i class="fas fa-warehouse w-5 mr-3"></i>
                        Inventory
                    </a>
                    <a href="{{ route('pharmacy.dispensing') }}" class="sidebar-link">
                        <i class="fas fa-hand-holding-medical w-5 mr-3"></i>
                        Dispensing
                    </a>
                    <a href="{{ route('pharmacy.reports') }}" class="sidebar-link">
                        <i class="fas fa-chart-line w-5 mr-3"></i>
                        Reports
                    </a>
                @endrole
                
                @role('reception')
                    <a href="{{ route('reception.dashboard') }}" class="sidebar-link {{ request()->is('reception/*') ? 'active' : '' }}">
                        <i class="fas fa-desktop w-5 mr-3"></i>
                        Reception Dashboard
                    </a>
                    <a href="{{ route('reception.patient-registration') }}" class="sidebar-link">
                        <i class="fas fa-user-plus w-5 mr-3"></i>
                        Patient Registration
                    </a>
                    <a href="{{ route('reception.patients') }}" class="sidebar-link">
                        <i class="fas fa-users w-5 mr-3"></i>
                        Patients
                    </a>
                    <a href="{{ route('reception.appointments') }}" class="sidebar-link">
                        <i class="fas fa-calendar-alt w-5 mr-3"></i>
                        Appointments
                    </a>
                    <a href="{{ route('reception.billing') }}" class="sidebar-link">
                        <i class="fas fa-file-invoice-dollar w-5 mr-3"></i>
                        Billing
                    </a>
                @endrole
                
                <a href="{{ route('reports') }}" class="sidebar-link">
                    <i class="fas fa-file-alt w-5 mr-3"></i>
                    Reports
                </a>
            </nav>
            
            <div class="absolute bottom-0 w-64 p-4 border-t border-gray-200">
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit" class="w-full text-left sidebar-link text-red-600 hover:bg-red-50">
                        <i class="fas fa-sign-out-alt w-5 mr-3"></i>
                        Logout
                    </button>
                </form>
            </div>
        </div>
        @endif
        
        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Top Header -->
            @auth
            <header class="bg-white shadow-sm border-b border-gray-200">
                <div class="px-6 py-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-2xl font-semibold text-gray-800">@yield('header', 'Dashboard')</h2>
                        </div>
                        <div class="flex items-center space-x-4">
                            <span class="text-sm text-gray-600">{{ now()->format('M d, Y h:i A') }}</span>
                            <div class="relative">
                                <img src="{{ auth()->user()->profile_photo_url }}" alt="Profile" class="w-10 h-10 rounded-full">
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            @endif
            
            <!-- Page Content -->
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
                <div class="container mx-auto px-6 py-8">
                    <!-- Flash Messages -->
                    @if (session('message'))
                        <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                            {{ session('message') }}
                        </div>
                    @endif
                    
                    @if (session('error'))
                        <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                            {{ session('error') }}
                        </div>
                    @endif
                    
                    @yield('content')
                </div>
            </main>
        </div>
    </div>
    
    <!-- Livewire Scripts -->
    @livewireScripts
    
    <!-- Custom Scripts -->
    <script>
        // Auto-hide flash messages
        setTimeout(() => {
            const messages = document.querySelectorAll('.bg-green-100, .bg-red-100');
            messages.forEach(msg => msg.remove());
        }, 5000);
    </script>
</body>
</html>