<div>
    <!-- Progress Indicator -->
    <div class="mb-8">
        <div class="flex items-center justify-between mb-4">
            @for ($i = 1; $i <= $totalSteps; $i++)
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold
                        {{ $currentStep >= $i ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600' }}">
                        {{ $i }}
                    </div>
                    @if ($i < $totalSteps)
                        <div class="w-16 h-1 mx-2 {{ $currentStep > $i ? 'bg-blue-600' : 'bg-gray-200' }}"></div>
                    @endif
                </div>
            @endfor
        </div>
        <div class="flex justify-between text-sm text-gray-600">
            <span>Basic Info</span>
            <span>Contact Info</span>
            <span>Ayurvedic Info</span>
        </div>
    </div>

    <!-- Form Content -->
    @if ($currentStep == 1)
        <!-- Step 1: Basic Information -->
        <div class="card p-6">
            <h3 class="text-lg font-semibold mb-4">Basic Information</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">UHID</label>
                    <input type="text" :value="$uhid" readonly
                           class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input type="text" wire:model="full_name"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    @error('full_name')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Gender *</label>
                    <div class="flex space-x-4">
                        <label class="flex items-center">
                            <input type="radio" wire:model="gender" value="Male" class="mr-2">
                            <span>Male</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" wire:model="gender" value="Female" class="mr-2">
                            <span>Female</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" wire:model="gender" value="Other" class="mr-2">
                            <span>Other</span>
                        </label>
                    </div>
                    @error('gender')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
                    <input type="date" wire:model="date_of_birth" wire:input="updatedDateOfBirth"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    @error('date_of_birth')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Age</label>
                    <input type="number" :value="$age" readonly
                           class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Aadhaar Number</label>
                    <input type="text" wire:model="aadhaar_number" maxlength="12"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="123456789012">
                    @error('aadhaar_number')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
            </div>
        </div>
    @endif

    @if ($currentStep == 2)
        <!-- Step 2: Contact Information -->
        <div class="card p-6">
            <h3 class="text-lg font-semibold mb-4">Contact Information</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Mobile Number *</label>
                    <input type="tel" wire:model="mobile" maxlength="10"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="9876543210">
                    @error('mobile')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input type="email" wire:model="email"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="patient@example.com">
                    @error('email')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Emergency Contact Name *</label>
                    <input type="text" wire:model="emergency_contact_name"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="John Doe">
                    @error('emergency_contact_name')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Emergency Contact *</label>
                    <input type="tel" wire:model="emergency_contact" maxlength="10"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="9876543210">
                    @error('emergency_contact')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Address *</label>
                    <textarea wire:model="address" rows="3"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="Enter complete address"></textarea>
                    @error('address')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
            </div>
        </div>
    @endif

    @if ($currentStep == 3)
        <!-- Step 3: Ayurvedic Information -->
        <div class="card p-6">
            <h3 class="text-lg font-semibold mb-4">Ayurvedic Information</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Prakriti *</label>
                    <select wire:model="prakriti"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Select Prakriti</option>
                        <option value="Vata">Vata</option>
                        <option value="Pitta">Pitta</option>
                        <option value="Kapha">Kapha</option>
                        <option value="Sama">Sama</option>
                    </select>
                    @error('prakriti')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Registration Type *</label>
                    <div class="flex space-x-4">
                        <label class="flex items-center">
                            <input type="radio" wire:model="registration_type" value="OPD" class="mr-2">
                            <span>OPD</span>
                        </label>
                        <label class="flex items-center">
                            <input type="radio" wire:model="registration_type" value="IPD" class="mr-2">
                            <span>IPD</span>
                        </label>
                    </div>
                    @error('registration_type')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Dosha Types *</label>
                    <div class="space-y-2">
                        <label class="flex items-center">
                            <input type="checkbox" wire:model="dosha_types" value="Vata" class="mr-2">
                            <span>Vata</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" wire:model="dosha_types" value="Pitta" class="mr-2">
                            <span>Pitta</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" wire:model="dosha_types" value="Kapha" class="mr-2">
                            <span>Kapha</span>
                        </label>
                    </div>
                    @error('dosha_types')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Allergies</label>
                    <textarea wire:model="allergies" rows="3"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="List any known allergies"></textarea>
                    @error('allergies')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Patient Photo</label>
                    <input type="file" wire:model="photo"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                           accept="image/*">
                    <p class="text-sm text-gray-500 mt-1">Max file size: 2MB (JPEG, PNG, JPG)</p>
                    @error('photo')
                        <span class="text-red-500 text-sm">{{ $message }}</span>
                    @enderror
                    
                    @if ($photo)
                        <div class="mt-2">
                            <img src="{{ $photo->temporaryUrl() }}" alt="Preview" class="w-32 h-32 object-cover rounded">
                        </div>
                    @endif
                </div>
            </div>
        </div>
    @endif

    <!-- Navigation Buttons -->
    <div class="flex justify-between mt-8">
        @if ($currentStep > 1)
            <button wire:click="previousStep" class="btn btn-secondary">
                <i class="fas fa-arrow-left mr-2"></i>
                Back
            </button>
        @else
            <div></div>
        @endif

        @if ($currentStep < $totalSteps)
            <button wire:click="nextStep" class="btn btn-primary">
                Next
                <i class="fas fa-arrow-right ml-2"></i>
            </button>
        @else
            <button wire:click="submit" class="btn btn-success">
                <i class="fas fa-check mr-2"></i>
                Register Patient
            </button>
        @endif
    </div>
</div>