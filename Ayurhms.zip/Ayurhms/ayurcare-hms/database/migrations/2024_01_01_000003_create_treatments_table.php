<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('treatments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained()->onDelete('cascade');
            $table->foreignId('doctor_id')->constrained('users')->onDelete('cascade');
            $table->string('name');
            $table->string('type'); // Nasya, Shirodhara, etc.
            $table->date('start_date');
            $table->date('end_date');
            $table->enum('status', ['Active', 'Completed', 'Cancelled'])->default('Active');
            $table->string('room')->nullable();
            $table->text('notes')->nullable();
            $table->json('schedule_options')->nullable();
            $table->decimal('cost', 10, 2)->default(0);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('treatments');
    }
};