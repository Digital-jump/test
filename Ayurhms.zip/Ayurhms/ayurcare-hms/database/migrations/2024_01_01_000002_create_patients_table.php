<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();
            $table->string('uhid')->unique(); // Auto-generated format: AYR-YYYY-XXXX
            $table->string('full_name');
            $table->enum('gender', ['Male', 'Female', 'Other']);
            $table->date('date_of_birth');
            $table->integer('age');
            $table->string('aadhaar_number')->nullable();
            $table->json('contact_info'); // Mobile, Email, Emergency Contact, Address
            $table->json('ayurvedic_info'); // Prakriti, Dosha, Allergies, Registration type
            $table->string('photo')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patients');
    }
};