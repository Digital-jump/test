<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create roles
        $roles = [
            'admin',
            'doctor',
            'pharmacy',
            'reception'
        ];

        foreach ($roles as $role) {
            Role::create(['name' => $role]);
        }

        // Create permissions
        $permissions = [
            // Patient permissions
            'view patients',
            'create patients',
            'edit patients',
            'delete patients',
            
            // Treatment permissions
            'view treatments',
            'create treatments',
            'edit treatments',
            'delete treatments',
            
            // Medicine permissions
            'view medicines',
            'create medicines',
            'edit medicines',
            'delete medicines',
            'dispense medicines',
            
            // Billing permissions
            'view transactions',
            'create transactions',
            'edit transactions',
            'delete transactions',
            
            // Appointment permissions
            'view appointments',
            'create appointments',
            'edit appointments',
            'delete appointments',
            
            // Report permissions
            'view reports',
            'generate reports',
            'export reports',
            
            // Admin permissions
            'view users',
            'create users',
            'edit users',
            'delete users',
            'manage settings'
        ];

        foreach ($permissions as $permission) {
            Permission::create(['name' => $permission]);
        }

        // Create admin user
        $admin = User::create([
            'name' => 'Admin User',
            'email' => 'admin@ayurcare.com',
            'password' => bcrypt('password'),
            'role' => 'admin',
            'phone' => '9876543210'
        ]);

        $admin->assignRole('admin');
        $admin->givePermissionTo(Permission::all());

        // Create sample doctor
        $doctor = User::create([
            'name' => 'Dr. Ayurveda',
            'email' => 'doctor@ayurcare.com',
            'password' => bcrypt('password'),
            'role' => 'doctor',
            'phone' => '9876543211',
            'specializations' => json_encode(['Panchakarma', 'Ayurveda'])
        ]);

        $doctor->assignRole('doctor');
        $doctor->givePermissionTo([
            'view patients', 'create patients', 'edit patients',
            'view treatments', 'create treatments', 'edit treatments',
            'view appointments', 'create appointments', 'edit appointments',
            'view reports'
        ]);

        // Create sample pharmacy user
        $pharmacy = User::create([
            'name' => 'Pharmacy User',
            'email' => 'pharmacy@ayurcare.com',
            'password' => bcrypt('password'),
            'role' => 'pharmacy',
            'phone' => '9876543212'
        ]);

        $pharmacy->assignRole('pharmacy');
        $pharmacy->givePermissionTo([
            'view medicines', 'create medicines', 'edit medicines',
            'dispense medicines', 'view transactions'
        ]);

        // Create sample reception user
        $reception = User::create([
            'name' => 'Reception User',
            'email' => 'reception@ayurcare.com',
            'password' => bcrypt('password'),
            'role' => 'reception',
            'phone' => '9876543213'
        ]);

        $reception->assignRole('reception');
        $reception->givePermissionTo([
            'view patients', 'create patients', 'edit patients',
            'view appointments', 'create appointments', 'edit appointments',
            'view transactions', 'create transactions'
        ]);
    }
}