# AyurCare HMS - Installation Guide

## Quick Start

### 1. System Requirements
- PHP 8.2 or higher
- MySQL 8.0 or higher
- Composer
- Node.js and npm
- Web server (Apache/Nginx)

### 2. Installation Steps

#### Step 1: Get the Code
```bash
# Clone the repository
git clone <your-repo-url>
cd ayurcare-hms

# Or download the ZIP file and extract it
```

#### Step 2: Install Dependencies
```bash
# Install PHP dependencies
composer install

# Install Node.js dependencies
npm install

# Build assets
npm run build
```

#### Step 3: Environment Configuration
```bash
# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate
```

#### Step 4: Database Setup
```bash
# Create a new database in MySQL
CREATE DATABASE ayurcare_hms;

# Update .env file with your database credentials
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ayurcare_hms
DB_USERNAME=your_db_username
DB_PASSWORD=your_db_password
```

#### Step 5: Run Migrations
```bash
# Run database migrations
php artisan migrate

# Seed the database with initial data
php artisan db:seed
```

#### Step 6: Storage Link
```bash
# Create symbolic link for storage
php artisan storage:link
```

#### Step 7: Start the Application
```bash
# Start the development server
php artisan serve

# Application will be available at http://localhost:8000
```

### 3. Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@ayurcare.com | password |
| Doctor | doctor@ayurcare.com | password |
| Pharmacy | pharmacy@ayurcare.com | password |
| Reception | reception@ayurcare.com | password |

### 4. Web Server Configuration

#### Apache Configuration
```apache
<VirtualHost *:80>
    ServerName ayurcare.local
    DocumentRoot /path/to/ayurcare-hms/public

    <Directory /path/to/ayurcare-hms/public>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name ayurcare.local;
    root /path/to/ayurcare-hms/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

### 5. Permissions

Set proper permissions for Laravel:
```bash
# Set storage and cache permissions
sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

### 6. Production Setup

#### Environment Variables for Production
```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://your-domain.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=ayurcare_hms
DB_USERNAME=production_user
DB_PASSWORD=secure_password

MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_ENCRYPTION=tls
```

#### Optimize Application
```bash
# Clear caches
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# Optimize configuration
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Create storage link
php artisan storage:link
```

#### Schedule Tasks
Add to your crontab:
```bash
* * * * * cd /path/to/ayurcare-hms && php artisan schedule:run >> /dev/null 2>&1
```

#### Queue Worker (if using queues)
```bash
# Start queue worker
php artisan queue:work

# Or use supervisor for production
```

### 7. Troubleshooting

#### Common Issues

1. **Class not found errors**
   ```bash
   composer dump-autoload
   ```

2. **Permission issues**
   ```bash
   sudo chmod -R 775 storage bootstrap/cache
   sudo chown -R www-data:www-data storage bootstrap/cache
   ```

3. **Database connection issues**
   - Check database credentials in .env
   - Ensure MySQL is running
   - Verify database exists

4. **Storage link issues**
   ```bash
   php artisan storage:link
   # If that doesn't work, create manually
   ln -s /path/to/ayurcare-hms/storage/app/public /path/to/ayurcare-hms/public/storage
   ```

5. **Asset compilation issues**
   ```bash
   npm install
   npm run build
   ```

#### Log Files
Check these files for errors:
- `storage/logs/laravel.log`
- Web server error logs
- PHP error logs

### 8. Backup Strategy

#### Database Backup
```bash
# Create backup
mysqldump -u username -p ayurcare_hms > backup_$(date +%Y%m%d).sql

# Restore backup
mysql -u username -p ayurcare_hms < backup_20240101.sql
```

#### File Backup
```bash
# Backup important files
tar -czf backup_$(date +%Y%m%d).tar.gz \
    app/ \
    database/ \
    resources/ \
    storage/app/ \
    .env
```

### 9. Security Considerations

1. **Change default passwords** after first login
2. **Use HTTPS** in production
3. **Set strong database credentials**
4. **Regular updates** of dependencies
5. **Firewall configuration** to restrict access
6. **Regular backups** of database and files
7. **Monitor logs** for suspicious activity

### 10. Support

For support and questions:
- Check the documentation in `docs/` directory
- Review error logs
- Contact development team
- Create issues in the repository

---

**Note**: This is a comprehensive hospital management system. Ensure you have proper backups and understand the system before deploying in production.