# AyurCare HMS - Ayurvedic Hospital Management System

A comprehensive Laravel-based Hospital Management System specifically designed for Ayurvedic healthcare facilities.

## Features

### 🏥 Patient Management
- **Multi-step Patient Registration** with form validation
- **Patient Dashboard** with comprehensive overview
- **Auto-generated UHID** (AYR-YYYY-XXXX format)
- **Ayurvedic-specific information** tracking (Prakriti, Dosha types, etc.)
- **Photo upload** with validation
- **Contact information** management

### 🩺 Treatment Management
- **Treatment tracking** with progress monitoring
- **Treatment types** (Nasya, Shirodhara, etc.)
- **Doctor assignment** and scheduling
- **Progress bars** and completion tracking
- **Treatment feedback** system
- **Alerts** for treatment completion

### 💊 Pharmacy Management
- **Medicine inventory** with stock tracking
- **Low stock alerts** and reorder management
- **Expiry tracking** with visual indicators
- **Dispensing screen** with stock validation
- **Batch management** and tracking
- **Restricted medicines** handling

### 💰 Billing Module
- **Invoice generation** with multiple payment methods
- **Automatic item calculation** (treatments, medications)
- **GST calculation** (18%)
- **PDF export** and print functionality
- **Payment status** tracking
- **Draft invoice** saving

### 👨‍⚕️ Doctor Management
- **Doctor profiles** with specializations
- **Schedule management** and availability
- **Commission tracking** and earnings
- **Performance analytics** and statistics
- **Patient load** visualization

### 📊 Reporting Module
- **Custom report generator** with filters
- **Multiple report types** (Patient, Revenue, Inventory, etc.)
- **Date range selection** with presets
- **Export functionality** (Excel, PDF)
- **Report templates** saving

## Technology Stack

- **Backend**: Laravel 11 with PHP 8.2+
- **Frontend**: Livewire 3 with Tailwind CSS
- **Database**: MySQL with Prisma ORM
- **Authentication**: Multi-role with Spatie Permissions
- **File Upload**: Intervention Image
- **Export**: Laravel Excel, DOMPDF
- **UI Components**: Custom responsive design

## Installation

### Prerequisites
- PHP 8.2 or higher
- MySQL 8.0 or higher
- Composer
- Node.js (for asset compilation)

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ayurcare-hms
   ```

2. **Install dependencies**
   ```bash
   composer install
   npm install
   npm run build
   ```

3. **Environment setup**
   ```bash
   cp .env.example .env
   php artisan key:generate
   ```

4. **Configure database**
   Update your `.env` file with database credentials:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=ayurcare_hms
   DB_USERNAME=your_username
   DB_PASSWORD=your_password
   ```

5. **Run migrations and seeders**
   ```bash
   php artisan migrate
   php artisan db:seed
   ```

6. **Link storage**
   ```bash
   php artisan storage:link
   ```

7. **Start the development server**
   ```bash
   php artisan serve
   ```

## Default Login Credentials

After running the seeder, you can use these credentials:

- **Admin**: admin@ayurcare.com / password
- **Doctor**: doctor@ayurcare.com / password
- **Pharmacy**: pharmacy@ayurcare.com / password
- **Reception**: reception@ayurcare.com / password

## Database Schema

### Core Tables
- **users** - Multi-role authentication
- **patients** - Patient information and medical data
- **treatments** - Treatment plans and tracking
- **medicines** - Medicine inventory management
- **prescriptions** - Doctor prescriptions
- **prescription_items** - Individual prescription items
- **transactions** - Billing and payments
- **appointments** - Patient appointments
- **treatment_feedback** - Patient feedback system

## Key Features Implementation

### Multi-step Patient Registration
- **Step 1**: Basic Information (Name, Gender, DOB, Age, Aadhaar)
- **Step 2**: Contact Information (Mobile, Email, Emergency Contact, Address)
- **Step 3**: Ayurvedic Information (Prakriti, Dosha, Allergies, Registration Type)
- **Progress indicator** with step navigation
- **Form validation** for each step
- **Auto-save** functionality

### Patient Dashboard
- **Header section** with patient details and quick actions
- **Ongoing Treatments** card with progress bars
- **Medications** card with remaining days
- **Appointments** card with upcoming schedules
- **Feedback** card for pending reviews
- **Stats overview** with treatment history

### Treatment Management
- **Treatment list** with status badges
- **Treatment detail modal** with full information
- **Add new treatment** form with type selection
- **Automatic alerts** for treatment completion
- **PDF export** for treatment plans

### Pharmacy Management
- **Inventory table** with sorting and filtering
- **Low stock alerts** with reorder functionality
- **Expiry tracking** with visual indicators
- **Dispensing screen** with stock validation
- **Audit trail** for all dispensations

### Billing Module
- **Patient selection** with search
- **Billable items** auto-pulled from records
- **Calculation area** with discounts and taxes
- **Multiple payment methods**
- **Receipt generation** with PDF export

## Security Features

- **Multi-role authentication** with permission-based access
- **Input validation** and sanitization
- **CSRF protection** on all forms
- **SQL injection prevention** with Eloquent ORM
- **File upload validation** and security
- **Audit logging** for sensitive actions

## Performance Optimizations

- **Database indexing** on frequently queried columns
- **Eager loading** to prevent N+1 queries
- **Caching** for frequently accessed data
- **Pagination** for large datasets
- **Optimized queries** with proper relationships

## Future Enhancements

- **SMS integration** for appointment reminders
- **Email notifications** for various events
- **Mobile app** for patients and doctors
- **Advanced analytics** with charts and graphs
- **Integration** with external medical systems
- **Telemedicine** features
- **API endpoints** for third-party integrations

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please contact the development team or create an issue in the repository.

---

**AyurCare HMS** - Modern Ayurvedic Hospital Management System